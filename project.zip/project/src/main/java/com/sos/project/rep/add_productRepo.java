package com.sos.project.rep;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sos.project.modal.Product;

public interface add_productRepo extends JpaRepository<Product, Integer> {
	
}
