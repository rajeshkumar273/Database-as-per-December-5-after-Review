package com.sos.project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sos.project.modal.Product;
import com.sos.project.rep.add_productRepo;

@Controller
public class GAlleryController {


	@Autowired
	private add_productRepo proRepo;
	
	@GetMapping("/gallery")
	public ModelAndView getAllProduct() {
		ModelAndView mav = new ModelAndView("gallery");
		List<Product> product = proRepo.findAll();
		mav.addObject("Products", product);
		return mav;
	}

}
