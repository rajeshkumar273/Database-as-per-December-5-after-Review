package com.sos.project.rep;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sos.project.modal.Coupon;

public interface CouponRepo extends JpaRepository<Coupon, Integer> {

}
