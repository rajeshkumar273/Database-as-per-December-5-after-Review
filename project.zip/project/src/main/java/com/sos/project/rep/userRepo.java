package com.sos.project.rep;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sos.project.modal.user;

public interface userRepo extends JpaRepository<user, Integer> {
	
	@Query(value = "select * from user where user_email = :email and password = :pass", nativeQuery = true)
	public user login(@Param("email") String email, @Param("pass") String pass);
	
}
