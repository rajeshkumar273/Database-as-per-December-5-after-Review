package com.sos.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.sos.project.modal.Event;
import com.sos.project.rep.eventRepo;

@Controller
public class EventController {
	
	@Autowired
	private eventRepo erepo;
	
	@GetMapping("/adevent")
	public String viewEvent(Model model)
	{
		model.addAttribute("Event", new Event());
		return "event";
	}
	
	@PostMapping("/addEvent")
	public String addeVent(Event event)
	{
		erepo.save(event);
		return "saved";
	}

}
