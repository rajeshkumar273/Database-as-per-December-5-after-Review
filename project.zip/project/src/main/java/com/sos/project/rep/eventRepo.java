package com.sos.project.rep;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sos.project.modal.Event;

public interface eventRepo extends JpaRepository<Event, Integer> {

}
