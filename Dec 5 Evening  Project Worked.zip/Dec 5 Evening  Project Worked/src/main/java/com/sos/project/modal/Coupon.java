package com.sos.project.modal;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Coupon {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int couponID;
	
	@Column(nullable=false)
	private int discount;
	
	private int eventid;
	
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(name = "eventid", insertable = false, updatable = false)
	private Event couponevent;


	public Coupon() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Coupon(int couponID, int discount, int eventid, Event couponevent) {
		super();
		this.couponID = couponID;
		this.discount = discount;
		this.eventid = eventid;
		this.couponevent = couponevent;
	}


	public int getCouponID() {
		return couponID;
	}


	public void setCouponID(int couponID) {
		this.couponID = couponID;
	}


	public int getDiscount() {
		return discount;
	}


	public void setDiscount(int discount) {
		this.discount = discount;
	}


	public int getEventid() {
		return eventid;
	}


	public void setEventid(int eventid) {
		this.eventid = eventid;
	}


	public Event getCouponevent() {
		return couponevent;
	}


	public void setCouponevent(Event couponevent) {
		this.couponevent = couponevent;
	}


	@Override
	public String toString() {
		return "Coupon [couponID=" + couponID + ", discount=" + discount + ", eventid=" + eventid + ", couponevent="
				+ couponevent + "]";
	}
	
	
	
	
}
