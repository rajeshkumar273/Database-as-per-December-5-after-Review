package com.sos.project.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class user {
	
	@Id
	private String user_email;
	
	@Column(nullable=false)
	private String user_name;
	
	@Column(nullable=false,unique=true)
	private String phone_number;
	
	@Column(nullable=false)
	private String password;

	public String getUser_email() {
		return user_email;
	}

	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public user(String user_email, String user_name, String phone_number, String password) {
		super();
		this.user_email = user_email;
		this.user_name = user_name;
		this.phone_number = phone_number;
		this.password = password;
	}

	public user() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "user [user_email=" + user_email + ", user_name=" + user_name + ", phone_number=" + phone_number
				+ ", password=" + password + "]";
	}
	
	

}
