package com.sos.project.rep;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sos.project.modal.category;

public interface caterepo extends JpaRepository<category, Integer> {

}
