package com.sos.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.sos.project.modal.user;
import com.sos.project.rep.add_productRepo;
import com.sos.project.rep.userRepo;

@Controller
public class userController {
	
	@Autowired
	private userRepo uRepo;
	
	
	@GetMapping("/signup")
	public String viewusersignup(Model model)
	{
		model.addAttribute("user", new user());
		return "signup";
	}
	
	@PostMapping("/qwer")
	public String adduser(user user)
	{
		uRepo.save(user);
		return "Ulogin";
	}
	
	@GetMapping("/userlogin")
	public String viewUlogin()
	{
		return "Ulogin";
	}
	
	
	@PostMapping("/afterlogin")
	public String dologin(@RequestParam("e_mail") String email,@RequestParam("password") String password)
	{
		user user = uRepo.login(email, password);
		if(user != null) {
			return "redirect:/gallery";
		}
		else {
			return "redirect:/userlogin";
		}
	}
	
}
