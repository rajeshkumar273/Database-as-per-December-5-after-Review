package com.sos.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.sos.project.modal.Product;
import com.sos.project.rep.add_productRepo;

@Controller
public class add_productController {
  
	@Autowired
	private add_productRepo proRepo;
	
	@GetMapping("/adproduct")
	public String viewadproduct(Model model)
	{
		model.addAttribute("Product", new Product());
		return "addproduct";
	}
	
	@PostMapping("/postproduct")
	public String addproduct(Product product)
	{
		proRepo.save(product);
		return "saved";
	}

	}
