package com.sos.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.sos.project.modal.Coupon;
import com.sos.project.rep.CouponRepo;

@Controller
public class CouponController {
	
	@Autowired
	private CouponRepo Crepo;
	
	@GetMapping("/adcoupon")
	public String viewcoupon(Model model)
	{ 
		model.addAttribute("Coupon", new Coupon());
		return "coupon";
	}

	@PostMapping("/addCoup")
	public String addCoupon(Coupon coupon)
	{
		Crepo.save(coupon);
		return "saved";
	}
}
