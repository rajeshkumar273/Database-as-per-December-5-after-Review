package com.sos.project.modal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Entity
@Table(name="admin")
@Getter
@Setter
@AllArgsConstructor
public class admin {
	@Id
	@Column(nullable=false,unique=true)
	private String e_mail;
	
	@Column(nullable=false)
	private String password;

	public admin() {
		super();
		// TODO Auto-generated constructor stub
	}

	public admin(String e_mail, String password) {
		super();
		this.e_mail = e_mail;
		this.password = password;
	}

	public String getE_mail() {
		return e_mail;
	}

	public void setE_mail(String e_mail) {
		this.e_mail = e_mail;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "admin [e_mail=" + e_mail + ", password=" + password + "]";
	}
	
	
	
}
