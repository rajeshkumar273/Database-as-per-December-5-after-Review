package com.sos.project.rep;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.sos.project.modal.admin;

public interface adminRep extends JpaRepository<admin,Integer> {
	
	@Query(value = "select * from admin where e_mail = :email and password = :pass", nativeQuery = true)
	public admin login(@Param("email") String email, @Param("pass") String pass);
	
}
